#include "s_uart.h"
#include "init.h"
#include "stdio.h"

sbit	WDT=0x90^4;      //P1.4
void	sputch(char ch);
char	sgetch(void);
void	sputs(char code *str);
void	main()
{	
	code char HEX[]="0123456789ABCDEF";
	unsigned char i;
	
	SimuUARTinit();
	//serial_baud_19200;
	TL0=0XFD;
	while(1)
	{
		sputch(sgetch());
		//sputs(HEX);
		//sputch(sgetch());
		/*
		sputch(HEX[TL00>>4  ]);
		sputch(HEX[TL00&0x0f]);
		sputch(' ');
		*/
		WDT=!WDT;
	}
}
void	sputch(char ch)
{
	while(!tTI);
	tSBUF=ch;
	tTI=0;
}
void	sputs(char code *str)
{
	while(*str)
	{
		if(rRI) sputch(sgetch());
		sputch(*str++);
	}
}
char	sgetch(void)
{
	while(!rRI) WDT=!WDT;;
	rRI=0;
	return(rSBUF);
}

