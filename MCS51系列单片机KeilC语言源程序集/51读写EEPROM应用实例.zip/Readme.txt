*** PROJEKT, bestehend aus 4 Teilen ***

** Write_EEPROM **

Write_EEPROM.Uv2
i2c_DEF.h
tst_I2C.c
Write_EEPROM.Opt
Globals.h

** Chip_Inc **

16550.h
81C90.h
phyCORE_591.h
LAB537.h
MCB517AC.h
PCF8584.H
CM517A.h
PIO_8255.h
RTC72421.h
DEF_BOARDS.H
MOD515.h
I2c_Chip_Lib.h

** I2C_Lib **

I2C_lib.c

** Inc_C51b_T2 **

LCD_DEF_LIB.h
ASCII2hex.h
BCD_HEX.H
bcd2hex.h
CG_RAM_Lib.H
CRC_16.H
Def_bits.h
DEF_INT.H
Defines.h
INTELHEX.H
ITOA.H
ASCI_hex.h
LRC.H
MAKROS.H
PACK_7T8.H
Ram_des.h
Ram_inv.h
Rom_chk.h
RS232_BD.h
sm_printf.h
SOFT_RES.H
TASTEN_LIB.H
tasten_matrix_lib.h
TIME_OUT_lib.H
centronics_lib.h
I2c_Lib.h
DEF_MIC.H

