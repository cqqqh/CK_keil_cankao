#include <reg52.h>
#include <string.h>


#define  TRUE           1
#define  FALSE          0
#define  uchar          unsigned char
#define  ushort          unsigned short
#define MAXDEVICES      3

sbit owEn=P1^0;
sbit owBsy=P1^1;
sbit owData=P1^2;
sbit owRst=P1^3;
sbit P14=P1^4;
sbit P15=P1^5;
sbit P16=P1^6;


void delay(int delay);
void Init_Rs232(void);
void led_blink(void);
void tx_char(unsigned char c);
void tx_str(unsigned char *str);
void tx_lfbs(void);
void setcrc16(ushort reset);
ushort docrc16(ushort cdata);
unsigned char rx_char(void);



//bit  owAcquire(void);
//bit owTouchReset(void);
//void usDelay(uchar);
//bit owTouchBit(bit sendbit);
//uchar owWriteByte(uchar sendbyte);
//uchar owTouchByte(uchar sendbyte);
//uchar owReadByte(void);
//int FindDevices(int family_code);
//void owFamilySearchSetup(int search_family);
//bit owNext(bit alarm_only);
//void owSerialNum(uchar *serialnum_buf, int do_read);
unsigned char Send_MatchRom(void);
void write_bit(char bitval);
void write_byte(char val);
void wdelay(int us);
unsigned char read_bit(void);
unsigned char first(uchar conditional);
unsigned char read_byte(void);
void write_bit(char bitval);
//extern void usDelay1(uchar);
//extern void usDelay2(void);
extern uchar docrc8(uchar,uchar);
extern uchar ow_reset(void);
extern uchar writedatalow(void);
extern uchar writedatahigh(void);
extern uchar readowdatabit(void);
extern uchar owtoggle(void);
extern void  delay_10ms(void);
