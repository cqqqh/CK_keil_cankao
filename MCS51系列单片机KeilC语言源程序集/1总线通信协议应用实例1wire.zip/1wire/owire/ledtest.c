#include <ledtest.h>

static int LastDiscrepancy;
static int LastFamilyDiscrepancy;
static int LastDeviceFlag;
static int USpeed = 0; // current 1-Wire Net communication speed
static int ULevel = 0; // current 1-Wire Net level
uchar  ROM_NO[8];
//uchar FamilySN[MAXDEVICES][8];
uchar crc8;
ushort utilcrc16;
bit c16;

static short oddparity[16] = { 0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0, 1, 1, 0 };
void main(void)
 {
 int y=0;
 int flag=0;
 //uchar test;
 //uchar receive;
 uchar temp1,temp2;
// uchar temp3,temp4;
// bit   crcbit;
 ushort lastcrc16;

   delay(100); 
   led_blink();
   Init_Rs232();
  
	delay(500);
   //init  conditional search status
   while(1)
       { 
       	         ow_reset();      
       	         write_byte(0xcc);   //LSB address          
                 write_byte(0x55);   //LSB address
                 write_byte(0x07);   //MSB address
                 write_byte(0x00);   //LSB address
                 if (flag==0)
                     {
                      write_byte(0x76);   //MSB address
                     }
                 else{
                      write_byte(0x56);   //MSB address
                     }    
		  temp1=read_byte();
		  temp2=read_byte();
						  // crcbit=read_bit();
                  setcrc16(0x0000);     //
                  docrc16(0x55);
                  docrc16(0x07);
                  docrc16(0x00);
		  if (flag==1)
			 {
                          docrc16(0x16);
                          }
			else{
			     docrc16(0x36);
			     }
				    
                             // read and calculate the read crc
                   docrc16(temp1);
                   lastcrc16 = docrc16(temp2);
                           // crc should now be 0xB001
                    if (lastcrc16 != 0xB001)
                         {
						   ow_reset();
				                
					      }
                         else{
			                 }  
		
        if (first(TRUE))
			 {
			    if(flag==0)
			        {
			     	 flag=1;
			        }
			  else{
			        flag=0;
			       }
			            	 	
				if(Send_MatchRom())
				        {	
 				    write_byte(0x55);   //write status
				    write_byte(0x07);   //LSB address
	                            write_byte(0x00);   //MSB address
					if (flag==1)
					    {
                                             write_byte(0x0e);  //LSB address
					   }
					else{
					       write_byte(0x6d);  //LSB address
						 }
                                    temp1=read_byte();
				    temp2=read_byte();
						  // crcbit=read_bit();
				     setcrc16(0x0000);     //
                                     docrc16(0x55);
                                     docrc16(0x07);
                                     docrc16(0x00);
					 if (flag==1)
					    {
                                             docrc16(0x0e);
					   }
					else{
					        docrc16(0x6d);
						 }
				    
                             // read and calculate the read crc
                                       docrc16(temp1);
                                      lastcrc16 = docrc16(temp2);
                           // crc should now be 0xB001
                    if (lastcrc16 != 0xB001)
                         {
						   ow_reset();
				                //tx_str("make PIOA high crc error!");
					      }
                         else{
	                          //tx_str("make PIOA high crc correct!");
			                 }
                            //tx_lfbs(); 
						  }
					 }
				}
  /*delay(255);  
     tx_str("Pelease input 1 or 2 or 3 or 4 or 5");
	 tx_lfbs();
     tx_str("case '1':Send 1_wire  reset");
	 tx_lfbs();
     tx_str("case '2':Performing search rom CODE");
	 tx_lfbs();
     tx_str("case '3':Performing SKIP READ ROM COMMAND");
     tx_lfbs();
     tx_str("case '4':Performing SKIP WRITE ROM COMMAND");
     tx_lfbs();
	 tx_str("case '5':read status  from ds2406!");
     tx_lfbs();
     tx_str("case '6':write one low bit!");
     tx_lfbs();
     tx_str("case '7':make PIOA high crc correct!");
	 tx_lfbs();
	 while(1)
	    {
     receive=rx_char();
  switch (receive)
        {
		  case '1':
		            tx_str("Send 1_wire  reset");
					tx_lfbs();
					if (ow_reset())
					      {   
						   tx_str("reset failure!");
						   tx_lfbs();
						   }
					 else  {
					       tx_str("reset success!");
						   tx_lfbs();
						   }
					break;
		  case '2':
		             tx_str("Performing search rom CODE");
					 tx_lfbs();
					 ow_reset();
					 first(FALSE);
                     if (ROM_NO[0]==0x12)
					       {
						       tx_str("Correct find Ds2406 family ROM code");
							   tx_lfbs();
						   }
				/*	tx_str("ROM_NO[0]=18");
                    tx_lfbs();
					   for (y=1;y<8;y++)
					       { 
						       tx_str("ROM_NO[");
							   tx_char(y+48);
                               tx_str("]=");
					             if (ROM_NO[y]>=128)
					                 {tx_char((ROM_NO[y]-80));
									 tx_str("    (ROM_NO>128)");			  	          
                                     }
					              else if (ROM_NO[y]<48)
					                   { tx_char((ROM_NO[y]+48));
					                    tx_str("    (ROM_NO<48)");			  			           
							           }
								  else{
								       tx_char(ROM_NO[y]);
									   }
                              tx_lfbs();
						  }*/
                     /*  tx_str("Performing send Match Rom");
					   tx_lfbs();
					  if(Send_MatchRom())
					      {
						    
 						   write_byte(0x55);   //write status
					       write_byte(0x07);   //LSB address
	                       write_byte(0x00);   //MSB address
                           write_byte(0x0e);  //LSB address
                           temp1=read_byte();
						   temp2=read_byte();
						  // crcbit=read_bit();
						   setcrc16(0x0000);     //
                           docrc16(0x55);
                           docrc16(0x07);
                           docrc16(0x00);
						   docrc16(0x0e);
                             // read and calculate the read crc
                           docrc16(temp1);
                           lastcrc16 = docrc16(temp2);
                           // crc should now be 0xB001
                           if (lastcrc16 != 0xB001)
                               {
							    ow_reset();
				                tx_str("make PIOA high crc error!");
					           }
                         else{
	                          tx_str("make PIOA high crc correct!");
			                 }
                            tx_lfbs(); 
						  }
					 break;
		    case '3':
			           tx_str("3:Performing SKIP Read Rom Command");
					    tx_lfbs();
					   for (y=0x0a;y<=0x0f;y++)
					      {
					    ow_reset();                
					    write_byte(0xCC);   //LSB address
	                    write_byte(0xF0);   //MSB address
					    write_byte(y);   //LSB address
	                    write_byte(0x00);   //MSB address
					    test=read_byte();
							   if (test==0xff)
							       {
								     tx_str("read_byte=0xff!");
									 tx_lfbs();
									}
							   else {	
	         				         tx_str("read_byte=");
									 tx_char((test+48));
									  tx_lfbs();
									}
                            }

			         break;
		  case '4':
		              tx_str("4:Performing SKIP Write Rom Command");
					    tx_lfbs();
						 for (y=0x0a;y<=0x0f;y++)
					      {
					       ow_reset();                
					       write_byte(0xCC);   //LSB address
	                       write_byte(0x0F);   //MSB address
					       write_byte(y);   //LSB address
	                       write_byte(0x00);   //MSB address
                           write_byte(y);   //LSB address
                           temp1=read_byte();
						   temp2=read_byte();
						  // crcbit=read_bit();
						   setcrc16(0x0000);     //
                           docrc16(0x0f);
                           docrc16(y);
                           docrc16(0x00);
						   docrc16(y);
                             // read and calculate the read crc
                           docrc16(temp1);
                           lastcrc16 = docrc16(temp2);
                           // crc should now be 0xB001
                           if (lastcrc16 != 0xB001)
                               {
							    ow_reset();
				                tx_str("write crc error!");
					           }
                         else{
	                          tx_str("write crc correct!");
			                 }
                            tx_lfbs();                
							 wdelay(10000);
						 }
						tx_str("3:Performing SKIP Read Rom Command");
					    tx_lfbs();
					   for (y=0x0a;y<=0x0f;y++)
					      {
					    ow_reset();                
					    write_byte(0xCC);   //LSB address
	                    write_byte(0xF0);   //MSB address
					    write_byte(y);   //LSB address
	                    write_byte(0x00);   //MSB address
					    test=read_byte();
						temp1=read_byte();
						temp2=read_byte();
						 setcrc16(0x0000);     //
                           docrc16(0xF0);
                           docrc16(y);
                           docrc16(0x00);
						   docrc16(test);
                             // read and calculate the read crc
                           docrc16(temp1);
                           lastcrc16 = docrc16(temp2);
                           // crc should now be 0xB001
                           if (lastcrc16 != 0xB001)
                               {
							    ow_reset();
				                tx_str("read crc error!");
					           }
                         else{
	                          tx_str("read crc correct!");
			                 }
							   if (test==0xff)
							       {
								     tx_str("read_byte=0xff!");
									 tx_lfbs();
									}
							   else {	
	         				         tx_str("read_byte=");
									 tx_char((test+55));
									  tx_lfbs();
									}
							   wdelay(10000);
                            }
                            break;
          case '5':
                   tx_str("read status  from ds2406!");
                   tx_lfbs();
		          for (y=0x00;y<0x08;y++)
					      {
					       ow_reset();                
					       write_byte(0xCC);   //LSB address
	                       write_byte(0xaa);   //MSB address
					       write_byte(y);   //LSB address
	                       write_byte(0x00);   //MSB address
                           test=read_byte();  //LSB address
                           temp1=read_byte();
						   temp2=read_byte();
						  // crcbit=read_bit();
						   setcrc16(0x0000);     //
                           docrc16(0xaa);
                           docrc16(y);
                           docrc16(0x00);
						   docrc16(test);
                             // read and calculate the read crc
                           docrc16(temp1);
                           lastcrc16 = docrc16(temp2);
                           // crc should now be 0xB001
                           if (lastcrc16 != 0xB001)
                               {
							    ow_reset();
				                tx_str("read status crc error!");
					           }
                         else{
	                          tx_str("read status crc correct!");
			                 }
                            tx_lfbs(); 
               			     if (test==0xff)
							       {
								     tx_str("read_byte=0xff!");
									 tx_lfbs();
									}
							   else {	
	         				         tx_str("read_byte=");
									 tx_char((test+48));
									  tx_lfbs();
									}
							 delay(5000);

						 }
						 break;
		    case '6':
			         tx_str("setup search  conditional");
					 tx_lfbs();
                     tx_str("make PIOA high start!");
                     tx_lfbs();
					       ow_reset();                
					       write_byte(0xCC);   //LSB address
	                       write_byte(0x55);   //MSB address
					       write_byte(0x07);   //LSB address
	                       write_byte(0x00);   //MSB address
                           write_byte(0x56);  //LSB address
                           temp1=read_byte();
						   temp2=read_byte();
						  // crcbit=read_bit();
						   setcrc16(0x0000);     //
                           docrc16(0x55);
                           docrc16(0x07);
                           docrc16(0x00);
						   docrc16(0x56);
                             // read and calculate the read crc
                           docrc16(temp1);
                           lastcrc16 = docrc16(temp2);
                           // crc should now be 0xB001
                           if (lastcrc16 != 0xB001)
                               {
							    ow_reset();
				                tx_str("make PIOB Low crc error!");
					           }
                         else{
	                          tx_str("make PIOB low crc correct!");
			                 }
                            tx_lfbs(); 
							 delay(5000);
			         tx_str("Performing search rom CODE");
					 tx_lfbs();
					 ow_reset();
					 first(TRUE);
                     if (ROM_NO[0]==0x12)
					       {
						       tx_str("conditional search Correct find Ds2406 family ROM code");
							   tx_lfbs();
							   }
                       tx_str("Performing send Match Rom");
					   tx_lfbs();
					  if(Send_MatchRom())
					      {
						    
 						   write_byte(0x55);   //write status
					       write_byte(0x07);   //LSB address
	                       write_byte(0x00);   //MSB address
                           write_byte(0x0e);  //LSB address
                           temp1=read_byte();
						   temp2=read_byte();
						  // crcbit=read_bit();
						   setcrc16(0x0000);     //
                           docrc16(0x55);
                           docrc16(0x07);
                           docrc16(0x00);
						   docrc16(0x0e);
                             // read and calculate the read crc
                           docrc16(temp1);
                           lastcrc16 = docrc16(temp2);
                           // crc should now be 0xB001
                           if (lastcrc16 != 0xB001)
                               {
							    ow_reset();
				                tx_str("make PIOA high crc error!");
					           }
                         else{
	                          tx_str("make PIOA high crc correct!");
			                 }
                            tx_lfbs(); 
						  }
						 break;
           case '7':
                   tx_str("make PIOA high start!");
                   tx_lfbs();
					       ow_reset();                
					       write_byte(0xCC);   //LSB address
	                       write_byte(0x55);   //MSB address
					       write_byte(0x07);   //LSB address
	                       write_byte(0x00);   //MSB address
                           write_byte(0x0e);  //LSB address
                           temp1=read_byte();
						   temp2=read_byte();
						  // crcbit=read_bit();
						   setcrc16(0x0000);     //
                           docrc16(0x55);
                           docrc16(0x07);
                           docrc16(0x00);
						   docrc16(0x0e);
                             // read and calculate the read crc
                           docrc16(temp1);
                           lastcrc16 = docrc16(temp2);
                           // crc should now be 0xB001
                           if (lastcrc16 != 0xB001)
                               {
							    ow_reset();
				                tx_str("make PIOA high crc error!");
					           }
                         else{
	                          tx_str("make PIOA high crc correct!");
			                 }
                            tx_lfbs(); 
							 
                             /*  ow_reset();                
					       write_byte(0xCC);   //LSB address
	                       write_byte(0x55);   //MSB address
					       write_byte(0x07);   //LSB address
	                       write_byte(0x00);   //MSB address
                           write_byte(0x6d);  //
                           temp1=read_byte();
						   temp2=read_byte();
						  // crcbit=read_bit();
						   setcrc16(0x0000);     //
                           docrc16(0x55);
                           docrc16(0x07);
                           docrc16(0x00);
						   docrc16(0x6d);
                             // read and calculate the read crc
                           docrc16(temp1);
                           lastcrc16 = docrc16(temp2);
                           // crc should now be 0xB001
                           if (lastcrc16 != 0xB001)
                               {
							    ow_reset();
				                tx_str("make PIOA low crc error!");
					           }
                         else{
	                          tx_str("make PIOA low crc correct!");
			                 }
                            tx_lfbs(); 
							 delay(10000);
							 ow_reset();                
					       write_byte(0xCC);   //LSB address
	                       write_byte(0xaa);   //MSB address
					       write_byte(0x07);   //LSB address
	                       write_byte(0x00);   //MSB address
                           test=read_byte();  //LSB address
                           temp1=read_byte();
						   temp2=read_byte();
						  // crcbit=read_bit();
						   setcrc16(0x0000);     //
                           docrc16(0xaa);
                           docrc16(0x07);
                           docrc16(0x00);
						   docrc16(test);
                             // read and calculate the read crc
                           docrc16(temp1);
                           lastcrc16 = docrc16(temp2);
                           // crc should now be 0xB001
                           if (lastcrc16 != 0xB001)
                               {
							    ow_reset();
				                tx_str("read status crc error!");
					           }
                         else{
	                          tx_str("read status crc correct!");
			                 }
                            tx_lfbs(); 
               			     if (test==0xff)
							       {
								     tx_str("read_byte=0xff!");
									 tx_lfbs();
									}
							   else if(test<=48) {	
	         				         tx_str("read_byte=");
									 tx_char((test+48));
									  tx_lfbs();
									}
									else {  tx_str("read_byte=");
									 tx_char((test));
									  tx_lfbs();
									}*/
						/* break;
		   case '8':
                           ow_reset();                
					       write_byte(0xCC);   //skip command
	                       write_byte(0x55);   //write status command
					       write_byte(0x07);   //LSB address
	                       write_byte(0x00);   //MSB address
                           write_byte(0x6d);  //data
                           temp1=read_byte();
						   temp2=read_byte();
						  // crcbit=read_bit();
						   setcrc16(0x0000);     //
                           docrc16(0x55);
                           docrc16(0x07);
                           docrc16(0x00);
						   docrc16(0x6d);
                             // read and calculate the read crc
                           docrc16(temp1);
                           lastcrc16 = docrc16(temp2);
                           // crc should now be 0xB001
                           if (lastcrc16 != 0xB001)
                               {
							    ow_reset();
				                tx_str("make PIOA low(Channel FF = 1 transistor off) crc error!");
					           }
                         else{
	                          tx_str("make PIOA low(Channel FF = 1 transistor off) crc correct!");
			                 }
                            tx_lfbs(); 
						//	 delay(10000);
						 break;
          default:   
		            tx_str("default break!");
					break;
		 }
		 }*/
   while(1);
  }

 /*unsigned char rx_char(void)
    {
	   while(!RI)
	      {;}
	   RI=0;
	   return SBUF;
	 }*/

void tx_str(unsigned char *str)
    {int i;
      for (i=0;i<strlen(str);i++)
	        {
			  tx_char(str[i]);
	        }
	}
void tx_char(unsigned char c)
   {
    while(!TI)
	  {
	   ;
	   }
	   TI=0;
	   SBUF=c;
	 }

void tx_lfbs(void)
    {int y;
		 tx_char(0x0A);
	 	for (y=0;y<70;y++)
			 {
              tx_char(0x08);
			}
	 }
void Led_blink(void)
  {
  int i;
      for(i=0;i<10;i++)
          {
           P15=1;
	       delay(200);
	       P15=0;
	       delay(200);
	      }
	}

void Init_Rs232(void)
   {IE=0X00;
    SCON=0x50;
    TMOD=0x20;
	TH1=0xfd;
	TL1=0xfd;
	TR1=1;
	TI=1;
   }

 void delay(int delay)
  {int i,j;
   for (i=0;i<delay;i++)
      for (j=0;j<255;j++);
   }


// WRITE_BIT - writes a bit to the one-wire bus, passed in bitval.
//
void write_bit(char bitval)
{
  if (bitval==0)
      {
	   writedatalow();
	   }
  else{
       writedatahigh();
	   }
}// Delay provides 16us per loop, plus 24us. Therefore delay(5) = 104us
// WRITE_BYTE - writes a byte to the one-wire bus.
//
/*void writedatalow(void)
  {
  }

void writedatahigh(void)
  {int count=6000;

   owData=0;
   owRst=0;
   wdelay(1);
   owData=1;
   owRst=1;
   owEn=1;
   owBsy=1;
   wdelay(1);
   owEn=0;
   while(count!=0)
       {
	     if(
   }*/

void write_byte(char val)
{
unsigned char i;
unsigned char temp;
for (i=0; i<8; i++) // writes byte, one bit at a time
{
temp = val>>i; // shifts val right 'i' spaces
temp &= 0x01; // copy that bit to temp
write_bit(temp); // write bit in temp into
}
wdelay(5);
}

unsigned char read_bit(void)
   {uchar owireda;
    owireda=readowdatabit();
/*	if (owireda ==0xff)
	       {
			   tx_str("read one bit program error!");
			 }
	if (owireda ==0x00)
	     {
		    tx_str("read one bit==0x00!");
			 }
    if (owireda ==0x01)
	     {
		    tx_str("read one bit==0x01!");
			 }
if ((owireda !=0x01)&&(owireda !=0x00)&&(owireda !=0xff))
         {
		    tx_str("read one bit program error !=0x01,0x00,0xff!");
			}*/
	return(owireda);
	}


void wdelay(int us)
   {
     int s;
	 for (s=0;s<us;s++);
	 }
//////////////////////////////////////////////////////////////////////////////
// OW_RESET - performs a reset on the one-wire bus and
// returns the presence detect. Reset is 480us, so delay
// value is (480-24)/16 = 28.5 - we use 29. Presence checked
// another 70us later, so delay is (70-24)/16 = 2.875 - we use 3.
//
/*unsigned char ow_reset(void)
{
unsigned char presence;
owData = 0; //pull DQ line low
wdelay(29); // leave it low for 480us
owData = 1; // allow line to return high
wdelay(3); // wait for presence
presence = owData; // get presence signal
wdelay(25); // wait for end of timeslot
return(presence); // presence signal returned
} // 0=presence, 1 = no part*/

//////////////////////////////////////////////////////////////////////////////
// READ_BYTE - reads a byte from the one-wire bus.
//
unsigned char read_byte(void)
{
unsigned char i;
unsigned char value = 0;
for (i=0;i<8;i++)
{
if(read_bit()) value|=0x01<<i; // reads byte in, one byte at a time and then
// shifts it left
wdelay(6); // wait for rest of timeslot
}
return(value);
}

unsigned char First(uchar conditional)
{int flag; 
 unsigned char g; // Output bit
 unsigned char x = 0; 
 unsigned char m = 1; // ROM Bit index
 unsigned char n = 0; // ROM Byte index
 unsigned char k = 1; // bit mask
 unsigned char discrepMarker = 0; // discrepancy marker
 unsigned char nxt; // return value

   LastDeviceFlag = FALSE;
   LastDiscrepancy = 0;
   
   nxt = FALSE; // set the next flag to false
   crc8=0;

   flag = ow_reset();

   if(flag||LastDeviceFlag) // no parts -> return false
      {
        LastDiscrepancy = 0; // reset the search
         return FALSE;
      }
  if (conditional)
          { write_byte(0xec);
		  }
  else{
      write_byte(0xF0);
      }
	  do
      // for all eight bytes
        {
         x = 0;
		/* if(read_bit==0xff)
		     {
			   tx_str("read one bit program error!");
			 }*/
         if(read_bit()==1)
		    {
		     x = 2;
            // tx_str(" first bit=1!");
            //  tx_lfbs();
	        }
         wdelay(6);
         if(read_bit()==1) 
		      {x |= 1; // and its complement
               // tx_str(" next bit=1!");
                 //tx_lfbs();
			   }
           if(x ==3) // there are no devices on the 1-wire
		        {
				  tx_str(" not find slave device!");
				   tx_lfbs();
                   break;
				}
           else
             {
               if(x>0) // all devices coupled have 0 or 1
                     g = x>>1; // bit write value for search
               else
                 {
// if this discrepancy is before the last
// discrepancy on a previous Next then pick
// the same as last time
                   if(m<LastDiscrepancy)
				           {
                            g = ((ROM_NO[n]&k)>0);
						   }
                   else // if equal to last pick 1
				       {
                            g = (m==LastDiscrepancy); // if not then pick 0
					   }
// if 0 was picked then record
// position with mask k
                   if (g==0) discrepMarker = m;
                 }
                 if(g==1) // isolate bit in ROM[n] with mask k
                      ROM_NO[n] |= k;
                else
                      ROM_NO[n] &= ~k;
                 write_bit(g); // ROM search write
                 m++; // increment bit counter m
                 k = k<<1; // and shift the bit mask k
                 if(k==0) // if the mask is 0 then go to new ROM
                      { // byte n and reset mask
                        crc8=docrc8(ROM_NO[n],crc8); // accumulate the CRC
                        n++; k++;
                      }
                }
         }while(n<8); //loop until through all ROM bytes 0-7
if(m<65||crc8) // if search was unsuccessful then
LastDiscrepancy=0; // reset the last discrepancy to 0
else
    {
// search was successful, so set lastDiscrep,
// lastOne, nxt
     LastDiscrepancy = discrepMarker;
     LastDeviceFlag = (LastDiscrepancy==0);
     nxt = TRUE; // indicates search is not complete yet, more
     tx_str("Find Device!");
	  tx_lfbs();
      // parts remain
}
return nxt;
}
// Perform Match ROM
//
unsigned char Send_MatchRom(void)
{
unsigned char i;
if(ow_reset()) 
  {
   tx_str("owire reset failure!");
   return FALSE;
   }
write_byte(0x55); // match ROM command
for(i=0;i<8;i++)
{
 write_byte(ROM_NO[i]); //send ROM code
}
return TRUE;
}

//--------------------------------------------------------------------------
// Reset crc16 to the value passed in
//
// 'reset' - data to set crc16 to.
//
void setcrc16(ushort reset)
{
   utilcrc16 = reset;
   return;
}
//--------------------------------------------------------------------------
// Calculate a new CRC16 from the input data short.  Return the current
// CRC16 and also update the global variable CRC16.
//
// 'portnum'  - number 0 to MAX_PORTNUM-1.  This number is provided to
//              indicate the symbolic port number.
// 'data'     - data to perform a CRC16 on
//
// Returns: the current CRC16
//
ushort docrc16(ushort cdata)
{
   cdata = (cdata ^ (utilcrc16 & 0xff)) & 0xff;
   utilcrc16 >>= 8;

   if (oddparity[cdata & 0xf] ^ oddparity[cdata >> 4])
     utilcrc16 ^= 0xc001;

   cdata <<= 6;
   utilcrc16  ^= cdata;
   cdata <<= 1;
   utilcrc16   ^= cdata;

   return utilcrc16;
}
