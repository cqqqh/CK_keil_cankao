#include "reg51.h"
#include "ps7219.h"

void  ps7219_reset()
{
unsigned char i;
ps7219_pin_RST=0;
for(i=0;i<125;i++)
ps7219_delay();
ps7219_pin_RST=1;
for(i=0;i<255;i++)
ps7219_delay();
ps7219_pin_RST=0;
for(i=0;i<125;i++)
ps7219_delay();
}

void  ps7219_init()
{
ps7219_reset();
ps7219_send_data(addr_scan_count,0x04);
ps7219_send_data(addr_light_con,0x0f);
ps7219_send_data(addr_trans_mode,0xff);
ps7219_send_data(addr_close,0x01);
}

void  ps7219_echo(unsigned char da_1,da_2,da_3,da_4)
{
	ps7219_send_data(0x01,da_1);
	ps7219_send_data(0x02,da_2);
    ps7219_send_data(0x03,da_3);
    ps7219_send_data(0x04,da_4);

}

void  ps7219_send_data(unsigned char addr,da)
{
unsigned char i,byte_out;
byte_out=addr;
ps7219_pin_DIN=1;
ps7219_pin_CLK=1;
ps7219_pin_LOAD=0;

for(i=0;i<8;i++)
{
ps7219_pin_CLK=1;
ps7219_pin_DIN=(bit)(byte_out&0x80);
byte_out=byte_out<<1;
ps7219_pin_CLK=0;
ps7219_delay();

}

ps7219_pin_CLK=1;
byte_out=da;
for(i=0;i<7;i++)
{
ps7219_pin_CLK=1;
ps7219_pin_DIN=(bit)(byte_out&0x80);
byte_out=byte_out<<1;
ps7219_pin_CLK=0;
ps7219_delay();

}
ps7219_pin_CLK=1;
ps7219_pin_LOAD=1;
ps7219_pin_DIN=(bit)(byte_out&0x80);
ps7219_pin_CLK=0;
ps7219_delay();
ps7219_pin_CLK=1;
}

void  ps7219_delay(void)
{
unsigned char i;
for(i=0;i<125;i++)
{}

}


