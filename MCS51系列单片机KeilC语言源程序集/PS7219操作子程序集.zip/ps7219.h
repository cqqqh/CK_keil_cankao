#define		addr_bit_1			0x01
#define		addr_bit_2			0x02
#define		addr_bit_3			0x03
#define		addr_bit_4			0x04
#define		addr_bit_5			0x05
#define		addr_bit_6			0x06
#define		addr_bit_7			0x07
#define		addr_bit_8			0x08
#define		addr_trans_mode		0x09
#define		addr_light_con		0x0a
#define		addr_scan_count		0x0b
#define		addr_close			0x0c
#define		addr_echo_test		0x0d


sbit	    ps7219_pin_RST  =    P1^4;
sbit		ps7219_pin_LOAD =    P1^5;
sbit		ps7219_pin_DIN	=    P1^6;
sbit		ps7219_pin_CLK	=    P1^7;



void  ps7219_init();
void  ps7219_reset();
void  ps7219_echo(unsigned char da_1,da_2,da_3,da_4);
void  ps7219_send_data(unsigned char addr,da);
void  ps7219_delay(void);
